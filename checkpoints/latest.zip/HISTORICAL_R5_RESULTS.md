# Furybook: накопительный checkpoint R5

Исходники: `8758f59b58a99f55332d9d2dacd62026d5e897cb`, дерево `d2a9d79f7e1d19dfa887a5ee55f74411c23714b1`; основа `384866c1233f9e7cbbea97b8a2497bd922efdef7`.

Это новая ограниченная реализация защиты ручного черновика, а не побайтовое восстановление утраченных Web/T19/T20. Изменены ровно пять файлов. Shared проверяет revision, захваченный вместе с черновиком, до принятия payload. Android и Desktop передают именно этот revision. Устаревший черновик получает Stale без подтверждаемого запроса или скрытого повторного применения. Нового Web caller здесь ещё нет.

## Свежие проверки исходников

Проверки выполнены до коммита на точных пяти зафиксированных файлах; соответствие Git-объектам проверено. При упаковке тесты и сборки не запускались.

- Настоящий RED: 1 тест, 1 failure, ожидался Stale, получен Ready. GREEN: 2 pass; эти два уже входят в Shared 479 и не прибавляются повторно.
- Shared: 479 pass. Два тяжёлых oracle/source-matrix companion исключены явно.
- Android: 63 host pass. Отдельная полная матрица 83 818 строк исключена.
- Desktop: 38 pass и 2 явных skip длинных matrix/lifecycle gates. Пропуски не являются покрытием.
- Прошла компиляция Shared JS, исходного Web main/test, Shared Android и Android main/host/instrumentation Kotlin. Instrumentation не запускалась на устройстве.

Исходные команды, результаты, логи, JUnit XML, сравнение RED/GREEN, before/after copies и привязка к коммиту находятся в `R5_evidence/`. Ошибки первоначальной настройки сохранены отдельно и не выдаются за поведенческий RED.

## Ограничения не сняты

Оригинальный полный Desktop matrix wrapper завершился FAILED по outer timeout. Исторический поток native assertions и отдельная lifecycle-проверка не превращают его в PASS; подробности без изменений в `ORIGINAL_384866c_RESULTS.md`.

Новые Web-экраны, их captured-draft caller, Web runtime, device/system/offline проверки, T19/T20 и независимое копирование остаются вне этого этапа. Прежняя блокировка браузера с неустановленным назначением не разрешена; браузер не запускался. Отвергнутый внешний вид не принят и не переработан. Production gates выключены; `releaseReady=false`. Push, deploy и live-data изменения не выполнялись.

## Самодостаточное восстановление

Архив содержит полный Git bundle без prerequisite, все 642 tracked-файла в `source/`, SHA-256 manifests и технические доказательства. Пустой consumer checkout восстановлен без внешней основы: точные commit/tree, все bytes, чистый status и Git integrity проверены.

После распаковки:

    git clone Furybook-8758f59-full.bundle furybook-restored
    git -C furybook-restored switch --detach 8758f59b58a99f55332d9d2dacd62026d5e897cb
    git -C furybook-restored fsck --full

Восстановление исходников не заменяет настройку зависимостей и новую проверку будущих изменений.
