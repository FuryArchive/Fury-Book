# Fury Book: исходный Android + Desktop checkpoint

Зафиксирован 13 октября 2026. Включены T01–T17, принятая авторская основа, ограниченно принятые Android source/host и Desktop source/исторические native-доказательства. Это функциональный WIP, не готовый выпуск и не визуально утверждённый интерфейс.

**Оригинальный полный Desktop Gradle/JUnit matrix run завершился FAILED из-за outer timeout. Полного matrix PASS нет.** Полный поток native assertions и отдельное исправление lifecycle приняты как два разных ограниченных доказательства, а не как замена failed результата на green.

- Основа: `f47a5256a66ddc5e1b7b5c1e204e57279fc7227f`.
- Точный checkpoint: `384866c1233f9e7cbbea97b8a2497bd922efdef7`.
- 45 commits, 269 изменённых путей, 641 tracked file.
- Источник архива: только неизменяемые Git-объекты этого commit. Незавершённые Web/UI и manual-race-guard изменения не включены.

## Сохранённая основа

T01–T17 содержат типизированные требования и независимые ценовые эталоны, идентичность экземпляров, общий планировщик, миграцию без выдуманной истории, атомарные покупки/Undo, точные envelope/receipts/outbox и legacy backup, platform storage и повторяемую синхронизацию. Shared-модели, owner/store/view привязка и operation ID различают карточку, review, подтверждение, повтор и reconciliation; acknowledged base и planned outcome не смешиваются.

Авторская основа отдельно различает четыре source-derived утверждения и три явных авторских решения. Исходные 83 818 case IDs сохранены; отдельный overlay меняет 3 922 ценовых записи. Цена ранга и валюта доступа не переизобретаются после создания. Новая инициализация требует подтверждения и отсутствующей записи, выдаёт floor(initialXP/1000) AP один раз; replay возвращает текущий head, не пополняет баланс и не создаёт фиктивную покупку. Natural Beauty остаётся creation-only; неизвестные source/identity факты не становятся разрешением покупки.

## Android: принятый ограниченный source/host-объём

Принят в `d4f358ce608564c92db9ed6cdc99d060f1f5d00d`. Существующие экраны используют Shared quote/review/confirmation, типизированные факты, ручные corrections, funding/history/Undo. Исправлены шесть замечаний, включая ручную правку от acknowledged canonical state вместо runtime-filtered копии, подавление legacy prices в canonical cards, сериализацию hint cache, actual/required значения и обновление root после FCP import.

- Исторический финальный public-module gate: **470 Shared, 63 Android host и 4 Desktop routing tests**, без failures/errors/skips. Уже отдельно завершённая Android matrix и два дорогих Shared companion исключены из этого broad gate, не посчитаны повторно.
- Отдельная Android host matrix: 1/1 PASS, ровно 83 818 исходных case IDs и 119 121 binding-model observations. Неизменность всех 116 consumed inputs подтверждена. Это модели на host, не Android rendered/input проверка каждого ряда и не новые paid receipts для каждого case.
- Shared JS compilation, Debug/test APK, release Kotlin и merged manifest проверены. Изоляция fixture/oracle подтверждена для проверенных APK assets, release manifest и 524 release compiled classes. Это не signed/shrunk release APK или установка.
- **Android device/instrumentation НЕ ЗАПУСКАЛИСЬ.** API26/target, Compose pixels/input, реальные filesystem/fsync/CAS, process-death/relaunch и system/offline gates остаются NOT VERIFIED. Скомпилированные тесты и activity recreation не заменяют эти доказательства.

## Desktop: функциональные исходники и исторические проверки

Production wiring и обычные inputs приняты в `a6187c84e3b1736a5274edcc3ef6ba168c6e602e`; native opaque-pixel test host зафиксирован в `f87ec32c2663f5552953e4f1749df32e10237711`. Существующие navigator/cards/FuryDialog используют общий plan, typed choices, явное confirmation, сохранённую историю, Undo и protected recovery. Добавлен строго читающий исторические receipt-price доказательства Shared decoder без текущего каталога/нового platform parser.

Исторический общий gate на `a6187c8`: **477 Shared + 33 native input + 4 routing tests**, без failures/errors/skips; Shared JS compilation и Desktop jar прошли. Это фактические mouse/key взаимодействия с production root/screens под offscreen native Compose/Skia и изолированными fixtures, не браузерный рендер и не native OS window.

Синтетический fixed20 путь отдельно доказывает 100→80 XP, state/store/root recreation, receipt и Undo→100. Реальная source Strength0→1 за55 XP и Combat Cries morale/chi AP проверены отдельно. Синтетический сценарий не утверждает реальную source identity Block: его unresolved/ChoiceRequired/Unknown ограничения остаются. Проверялись удержание A/B-команд, повтор, stale review, типизированные варианты, explicit manual/funding, faults/recovery и локальное отображение конфликта без live cloud union.

Внешний вид пользователь отверг. Это только функциональная работа; visual acceptance, redesign и polish этим checkpoint не заявлены.

## Desktop matrix: точный результат без завышения

В оригинальном завершённом assertion body независимо проверены **все 83 818 исходных IDs в исходном порядке и 119 121 непрерывных native observations**, без пропусков/лишних IDs. Каждая запись создавалась после price/status/ordered-row/history assertions, native frame advance/capture и opaque/contrast checks. Финальный COMPLETE наступил после последнего утверждения. Наблюдения: Ready 27 696, Blocked 88 785, ChoiceRequired 2 640.

Это не OCR каждого glyph, не гарантия одновременной видимости длинных scroll rows, не системные gestures и не per-row покупки. **Новых paid receipts в matrix: 0.**

Оригинальный outer Gradle/JUnit run сохранил **exit1, 1 test/1 failure**, после 2 860 секунд; test time 2 827.325 секунды. Причина: `UncompletedCoroutinesError`, внешний default timeout 60 секунд. Watchdog не останавливал этот run. Наличие COMPLETE не делает wrapper успешным; ранние частичные runs также не складываются в PASS.

Отдельно принят настоящий same-host lifecycle RED→GREEN длительностью более 65 реальных секунд:

- Default RED: 65.309 секунды, 229 native frames, body завершён, wrapper не вернулся; тот же outer timeout.
- Invocation-only finite timeout 5 400 секунд GREEN: 65.368 секунды, 222 frames, body и wrapper нормально завершились, 0 failures/errors/skips.

Это проверка исправления outer lifecycle, не полный повтор matrix и не 65-секундная выборка вместо всех assertions. Не ослаблялись цены, source ожидания, assertions или глобальные настройки.

Сохранены exact historical source/resource/compiler inputs, outputs, production runtime/JARs и зависимости. **Оригинальные test-class binaries полного matrix отдельно не были сохранены до следующей lifecycle compile.** Позднейшие 414 pilot inputs не названы оригинальными matrix binaries. Поэтому нет утверждения о полном побайтовом архиве исходного test runtime. Эти частные проверочные материалы не включены в данный source ZIP.

## Финальный commit и более поздняя работа

`384866c` добавляет только test/doc упаковку: два long-native gates становятся opt-in, обычный запуск пропускает их явно, dedicated init задаёт bounded 5 400 секунд. Исходные 33 input methods и все matrix assertions сохранены. **На момент приёмки этого snapshot compile/default-two-skips/dedicated-selection smoke новых guards оставался pending.** Исторический lifecycle GREEN исполнялся до добавления этих guards. Позднейшие проверки в Web-работе не включены и не переатрибутированы этому snapshot; skips не являются coverage.

Новая Web UI-работа T18C и отдельная Shared/three-adapter защита от устаревшей base revision ручной правки находятся за пределами архива. Этот freeze ещё не содержит той защиты. Более ранние Web исходники T14/T17 и принятый fail-closed owner test сохранены, но это не приёмка новой Web UI.

Текущий Firefox pilot остановлен внешним запретом с указанием неуточнённого lookalike-домена; повтор или обход не выполнялся. Конкретный домен/факт передачи данных этим сообщением не установлен. Нового Web runtime acceptance нет. При упаковке браузер не запускался и не опрашивался.

## Общие незакрытые границы

Effective price view: **46 073 confirmed / 37 745 source-unverified**. Confirmed rows делятся на 27 606 admission-blocked, 2 008 compound fixture gaps и 16 459 receipt-eligible. Последняя группа опирается на отдельно сохранённое неизменное финансовое доказательство, а не на новые platform receipts. 37 745 unverified включают 12 264 numeric Unknown, 23 039 numeric Known-but-unverified и 2 442 symbolic-rank unencodable. Известная цена не означает разрешение покупки. Независимая compound/source/identity полнота остаётся открытой.

- Исторический полный Python suite RED: 399 passed, 37 failed, 6 errors, 4 skipped. 43 красных узла остаются на T19; complement с 43 deselected не является full green.
- Desktop native OS resize/focus, real FileDialog, process death/relaunch и настоящее offline/system поведение не подтверждены. Offscreen recreation не заменяет OS restart.
- Cold-offline Web startup, managed server/PostgREST/GoTrue/JWT, live rollout, old binaries и managed capacity/latency не подтверждены.
- Остаются визуальный redesign, финальные platform/source/release проверки T19 и T20 receipt-backup/restore, Windows/macOS durability и physical power loss.

Production local/cloud rollout gates остаются false; Android `localDurable=false`, `cloudLedgerV2=false`. **releaseReady=false.** Архив не разрешает включать production writes. Push/PR/merge/deploy, live-data, credentials или security изменения при упаковке не выполнялись.

## Содержимое и восстановление

Ровно четыре члена: `RESULTS.md`, `CHANGED_FILES.txt`, `furybook-android-desktop.bundle`, `furybook-android-desktop.patch`. Частные отчёты, служебные заметки и логи отсутствуют. Список изменений содержит статусы и SHA256 конечных файлов.

Оба способа требуют уже имеющийся указанный base commit. В отдельном чистом checkout основы:

    git bundle verify /path/to/furybook-android-desktop.bundle
    git fetch /path/to/furybook-android-desktop.bundle refs/heads/accepted-checkpoint:refs/heads/furybook-android-desktop
    git switch --detach 384866c1233f9e7cbbea97b8a2497bd922efdef7

Либо в другом чистом checkout основы:

    git apply --check /path/to/furybook-android-desktop.patch
    git apply --index /path/to/furybook-android-desktop.patch

Bundle восстанавливает точный commit и историю; binary-safe patch только такое же дерево файлов. Не применяйте оба способа поверх одних изменений или patch поверх незавершённой работы.

Контроль доставки: ZIP CRC и точный allowlist, bundle prerequisites и чистый checkout принятого commit, patch-tree equality и SHA256 всех 641 tracked file и 269 изменённых путей. Отдельно полученная Library consumer-копия проходит те же restore/hash проверки и побайтовое сравнение с исходным ZIP. Это восстановление исходников, не T20 receipts backup/restore. Тесты/сборки приложения при упаковке не выполнялись.
