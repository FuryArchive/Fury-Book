from pathlib import Path
import argparse,os,json,subprocess,signal,time,urllib.parse,hashlib
p=argparse.ArgumentParser();p.add_argument('--name',required=True);p.add_argument('--bound',type=int,default=900);p.add_argument('tasks',nargs=argparse.REMAINDER);a=p.parse_args()
root=Path.cwd();h=root/'.private/r5-reconstruction-20261013';tool=root.parent/'toolchain';home=tool/'build-home';jdk=json.loads((tool/'jdk17/verified-install.json').read_text())['javaHome'];env=dict(os.environ);env.update(JAVA_HOME=jdk,GRADLE_USER_HOME=str(tool/'gradle-cache'),HOME=str(home),ANDROID_USER_HOME=str(tool/'android-user-home'));env['PATH']=jdk+'/bin:'+env.get('PATH','')
for path in [home,tool/'gradle-cache',tool/'android-user-home']:path.mkdir(parents=True,exist_ok=True)
args=['./gradlew','--no-daemon','--no-parallel','--max-workers=2','--no-build-cache','--console=plain','-Pandroid.builder.sdkDownload=false','-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts']
proxy=urllib.parse.urlsplit(env.get('HTTPS_PROXY') or env.get('https_proxy') or '')
if proxy.hostname and proxy.port:args+=['-Dhttps.proxyHost='+proxy.hostname,'-Dhttps.proxyPort='+str(proxy.port),'-Dhttp.proxyHost='+proxy.hostname,'-Dhttp.proxyPort='+str(proxy.port)]
args+=a.tasks
(h/(a.name+'.command.json')).write_text(json.dumps({'args':args,'environment':{k:env[k] for k in ['JAVA_HOME','GRADLE_USER_HOME','HOME','ANDROID_USER_HOME']},'boundSeconds':a.bound},indent=2)+'\n')
start=time.monotonic();reason=None
with (h/(a.name+'.log')).open('w') as log:
 child=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (h/(a.name+'.supervisor.json')).write_text(json.dumps({'pid':child.pid,'startedUnix':time.time(),'ownStartStat':Path('/proc/'+str(child.pid)+'/stat').read_text()},indent=2)+'\n')
 while child.poll() is None:
  try:child.wait(timeout=min(30,max(1,a.bound-(time.monotonic()-start))))
  except subprocess.TimeoutExpired:print('R5_BUILD_PROGRESS|'+a.name+'|elapsedSeconds='+str(round(time.monotonic()-start)),flush=True)
  if child.poll() is None and time.monotonic()-start>=a.bound:
   reason='Overall bound reached'
   for sig,timeout in [(signal.SIGINT,20),(signal.SIGTERM,20),(signal.SIGKILL,10)]:
    if child.poll() is not None:break
    os.killpg(child.pid,sig)
    try:child.wait(timeout=timeout)
    except subprocess.TimeoutExpired:pass
   break
 code=child.wait()
result={'exitCode':code,'durationSeconds':round(time.monotonic()-start),'stopReason':reason};(h/(a.name+'.result.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);print((h/(a.name+'.log')).read_text()[-6000:],flush=True);raise SystemExit(code or (1 if reason else 0))
