# Furybook: fresh manual-draft revision guard

This is a newly reconstructed, bounded source change on exact accepted checkpoint `384866c1233f9e7cbbea97b8a2497bd922efdef7`, tree `5ee5b1dc2017c181f396ddca4e3a20d13901f8e4`. It is not a byte restoration of the lost later Web source and does not reuse historical executions as proof of the new code.

## Source contract

Exactly five source/test files change: Shared `AcquisitionController.kt` and `AcquisitionPresentationSession.kt`; Android `AndroidAcquisitionActions.kt`; Desktop `AcquisitionViews.kt`; new common `AcquisitionManualBaseRevisionTest.kt`.

The manual preparation API has an optional trailing nullable `expectedBaseRevision`. The Shared session checks it against the actual authoritative preparation load before adopting any review payload or revision. Android and Desktop pass the captured manual draft's revision, never a later preliminary reread revision. A mismatch settles Stale, without a confirmable request, retained operation ID, retry or refresh path. The old full patch cannot be automatically rebased; a newly captured explicit draft is required. Existing three-argument calls remain source-compatible, not precompiled binary-ABI-compatible. Grant, completion and other nonmanual behavior is unchanged. No schema, protocol, merge, engine, catalog, price or storage-format change is made.

The baseline has no Web manual-draft caller. That caller and Web acquisition screens are a separate subsequent source stage, not part of this change.

Exact source identities are in `five-file-freeze.json` (SHA256 `9f704e0f3dbaf67c7e201dc9128f4ab0a82eb121a6d9c599be424a55ae1cd5cd`) and complete patch `five-file.patch` (SHA256 `b0281f222e35aa4f71d4024eaf910c09f8068f1ce6a4fc7bda4284456caa351f`). Complete before/after copies are retained. Later verification confirmed all five identities unchanged.

## Fresh behavioral comparison

The complete regression was written before production edits. With all four production files still exactly at the accepted base, the real application port and serialized in-memory store reproduce an interleaving: capture a full size-edit patch at revision0, finish the UI-like preliminary read, pause the authoritative preparation read, commit an unrelated name edit at revision1, then resume preparation.

- Actual old-API RED: 1 executed test, 1 failure, expected Stale but actual Ready; exit1 after167seconds. This is a behavioral failure, not a missing API or setup failure.
- Guarded GREEN: 2 executed tests,0 failures/errors/skips; exit0 after46seconds. The rejected old draft cannot write or allocate an ID through confirm/retry/refresh. A new revision1 draft commits and preserves the competing name and balance. The separate existing three-argument call still works.
- RED and GREEN test source differ only in two explicit captured-base argument additions. The full interleaving, assertions and compatibility method are unchanged. This necessary API-call difference is disclosed.

The test exercises the real mutation coordinator/CAS and exact encoded-byte preservation, not native/disk durability or actual platform UI input.

## Fresh bounded affected gates

All executed against the same five-file source freeze:

- Shared:479 passes across67 fresh XML suites;0 failures/errors/skips. Two separately named heavy Shared oracle/source-matrix companions are excluded, so this is not the complete corpus gate. The2 focused R5 tests are included in479, not counted twice.
- Desktop:40 methods across2 fresh XML suites,38 passes and2 explicit default long-gate skips;0 failures/errors. Passes comprise33 original native-input methods,4 routing methods and1 pixel-pilot method. The full83818 renderer matrix and65-second long lifecycle method remain explicitly skipped, not silently filtered or counted as passes.
- Android:63 host passes across15 fresh XML suites;0 failures/errors/skips. Only the separate full83818 Android presentation-binding matrix is excluded.
- Actual compilation passes: Shared JS main/test, baseline Web JS main/test, Shared Android main, Android main/host test/instrumentation Kotlin. Compiled instrumentation was not executed.
- Shared/Desktop/JS command exit0 after344seconds; Android command exit0 after142seconds. All copied result XML timestamps and mtimes are newer than their invocation start, with per-file SHA256 inventories.
- `git diff --check` is clean; the only product/test changes remain the five reviewed files.

`affected-terminal-summary.json` SHA256 `9d1743312582f08a89f1b3f8c0f6450f5c9ec0aca43878e2673d887f6fcdd5f6`; `affected-android-terminal-summary.json` SHA256 `9b2b634e300ab527e55ffcd97a1cbd3895dfe6790d9023db0d52f6290763be98`. Exact commands, terminal logs/results, supervisor bounds and copied XML are retained separately.

## Toolchain and setup qualifications

The preinstalled Java21 directory was a runtime without a compiler; its initial failure before testing is not RED. The official Gradle9.7.0 bootstrap uses the repository's pinned SHA256. A task-local official Corretto17 JDK was installed with vendor checksum verification, preserving the configured project toolchain.

Official SDK command-line tools23 could not bootstrap the new AndroidCLI at its exact Google download URL because of Connection refused; this was a tool/network failure, not a permission denial. A documented pinned previous-version utility20 route uses ordinary Java sdkmanager. Only the same previously user-approved Android SDK license dated January16,2019 was accepted at its package-specific prompt: https://developer.android.com/studio/terms. No new legal agreement, telemetry opt-in or security setting was accepted. Official API37.0/build-tools37.0.0 were installed; the actual AGP gate then required its unchanged default Build Tools36.0.0, which was installed before the successful distinct retry. That9-second pre-test missing-package failure remains a setup failure, not a behavioral RED. No platform-tools warning was suppressed and no unnecessary device tooling was installed or used.

## Explicit remaining limits

This qualified source checkpoint is not full T18C, a release or visual acceptance. Baseline Web compilation does not prove reconstructed Web screens, its future captured-draft caller, native IndexedDB, controller callbacks, rendered Web pixels/input or offline Main bootstrap. The previously denied browser destination remains unresolved; no browser launch, retry, endpoint probe or settings change occurred in this stage.

Android OS/device/instrumentation execution, full matrices/system journeys, actual server capability, lost Web/T19/T20 source and later independent-copy persistence work remain outside this stage. Historical Desktop full-row assertion evidence remains qualified NOT PASS at its original outer wrapper, not converted into a fresh full-suite green result. Production capabilities and release readiness stay false. The rejected WIP appearance is not accepted or redesigned. No push, deploy, live-account change or device installation is performed.
