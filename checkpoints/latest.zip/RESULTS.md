# Furybook: накопительный Web source/compile checkpoint

Коммит `cfb3dd67efdff3c4810e91abb9a1180435de2cdf`, дерево `d6b20930e13cefc9c426800a536895c2ad650f7a`, основа `8758f59b58a99f55332d9d2dacd62026d5e897cb`. Включены все 650 tracked-файла и предыдущая защита R5.

## Что принято

Новая реконструкция Web-подключения принята только по исходникам и компиляции. Изменены 18 путей: 17 Web и раздел документа приёмки. Это не восстановление утраченных Web/T19/T20 побайтно и не полный T18/T18C PASS.

Сохранены раздельно исходный снимок с замечаниями и четырёхфайловое исправление W1/W2: защищённая классификация сохраняется после пустого успешного refresh; карточки и детали неполученных заклинаний используют парную Shared-котировку, требования и запрос. Подключён captured-draft Web caller защиты R5. Новой арифметики цен, схемы, production gate или визуального redesign нет.

Финальная обычная компиляция Web main и test действительно выполнена, exit 0 за 27 секунд; не только UP-TO-DATE. Она проходила до коммита на точных 18 файлах, теперь проверенных против Git-объектов. При архивировании сборки и тесты не запускались.

## Что НЕ проверено

Все 20 подготовленных браузерных методов НЕ ЗАПУЩЕНЫ: 10 binding/classification, 9 native-IDB/production-callback и 1 полная presentation-data матрица 83 818 строк. Компиляция не является JS test PASS или поведенческим RED/GREEN.

Браузер остаётся BLOCKED/STOPPED из-за прежнего запрета с неустановленным назначением. Запусков, повторов и обходов не было. Native persistence/callbacks, renderer/WebGL, реальные input/pixels, offline/system journeys и исполнение полной матрицы не подтверждены. Device/server/release/visual acceptance не заявлены. Отвергнутый внешний вид не принят. `releaseReady=false`.

## Сохранённые доказательства и восстановление

Все 52 исходных технических Web-артефакта сохранены неизменно. Сохранены технические части четырёхфайлового amendment и привязка финального коммита. Исходные manifests оставлены без изменений; исключённый текст reviewer report отмечен в экспортном inventory. 148 технических R5-файлов унаследованы побайтно из предыдущего проверенного архива и не выдаются за нынешние Web runtime-проверки.

Исторический полный Desktop matrix wrapper остаётся FAILED по outer timeout. Отдельные assertions и lifecycle-проверка не превращают его в PASS. Подробные прежние ограничения сохранены в `ORIGINAL_384866c_RESULTS.md` и `HISTORICAL_R5_RESULTS.md`.

Полный Git bundle не требует внешней основы; папка `source/` содержит все tracked-файлы. В пустом consumer checkout проверены commit/tree, все bytes и Git-объекты, чистый status и Git integrity; в ZIP проверены CRC и SHA-256 manifests. Архивирование не выполняло push, deploy или изменения live data.

После распаковки:

    git clone Furybook-cfb3dd6-full.bundle furybook-restored
    git -C furybook-restored switch --detach cfb3dd67efdff3c4810e91abb9a1180435de2cdf
    git -C furybook-restored fsck --full
