# Furybook Web T18C: reconstructed functional source checkpoint

Base: `8758f59b58a99f55332d9d2dacd62026d5e897cb`, the separately reviewed and preserved fresh manual-draft revision guard. Binding requirements remain the tracked acquisition spec§10/§12 and original implementationT18. This stage is newly reconstructed source, not restoration of the lost later implementation or reuse of its acceptance.

## Bounded source result

18 changed paths:17 Web source/test/config files plus only the new Web subsection of `docs/acquisition-ui-acceptance.md`. Full file identities and complete frozen copies are recorded in `source-freeze.json` SHA256 `29c5b41527cd06b5a5742eee1b39756fb6c46b131a72d205efe64a69afd73934`; complete patch SHA256 `2e05b296813ec8dbb462bbc268641a350f6143b21895d03d0daa4c731971c554`. Two generated jsTest input files are also copied and hashed. Shared/Android/Desktop source, original independent oracles and the accepted R5 evidence bytes are unchanged.

The accepted existing Desktop functional surfaces provide the reference, adapted to Web's existing screens and crypto-backed `webUuid`, without visual redesign:

- Development, Skills, Magic and Character Sheet use the retained Shared acquisition controller. Cards use paired `quoteCardReview`, show unknown/blocked/choice outcomes, and cannot infer a fallback request before the paired review exposes one. Typed ability/instance/parameter choices, included/excluded targets, planned versus acknowledged-base requirements, actual/required typed values and witness explanations remain Shared-owned.
- Preview, error, receipt/history and reviewed Undo consume exact Shared values. The persisted saved-evidence typed field displays recorded operation/phase/revisions, sources and discount proofs; no platform financial parser or current repricing is introduced. Historical price/remainder and current balance are separate. A loading or failed history read is explicitly unavailable, never an invented empty journal.
- Manual edits transform the exact captured canonical character, not the Chi-suppressed runtime view. Both signed currency values and a reason are explicit. The Web caller passes the captured draft revision into the existing R5 Shared preparation guard. A stale old patch cannot be refreshed/retried/rebased as a new review.
- The existing Characters new-character hook opens Shared new-only funding. Initial AP comes from the accepted Shared policy; existing characters are not refilled. Canonical Characters and rail balances cannot fall back to legacy experience text.
- Initial native discovery is fail-closed while pending or failed, including character/extras setters and root cloud scheduling. Only a fully acknowledged empty/legacy classification can enable legacy mode. A previously classified protected refresh keeps navigation/search/root command state mounted, with explicit read failure/loading states. Stable acknowledged outcome/revision keys refresh the read view even when character snapshot fields are unchanged. Successful import recapture is separate from rejected import.
- The root sits outside the section key, holds the controller/actions across section reentry and disposes on root/account unmount. Native command execution and the mutable Shared hint cache use serialized lanes. Captured owner/account/controller generations prevent late callbacks writing a different owner. Automatic sheet-group normalization is suppressed in canonical mode; user edits stage a confirmed canonical nonfinancial review rather than legacy writes.
- Default production local capability remains false. Protected heads stay read-only, not legacy/cloud fallback. Existing cloud-only Main bootstrap behavior is not redesigned or represented as offline startup support.

The two recovered files alone have exact original bytes:

- `acquisition-live-counters.js`: SHA256 `8eac896ec1c1ba22a3459959845103f85cdf678a8380c144e514c65a97286801`.
- `acquisition-oracle.js`: SHA256 `9921b5cf81c4e45398b63aa316c88fc10e34bdea9002db573268083a2e2b4e73`.

The optional reporter retains its strict marker/output-path boundary and leaves official results intact. Its old task-private path is retained, not silently redirected. There is no arbitrary browser-log evaluation, transport change or browser setting change. All other source is new reconstruction.

## Fresh compilation and provenance

Actual bounded normal Gradle compilation, using the unchanged approved task-local JDK17/pinned Gradle toolchain:

1. Initial source compile: exit1 after21seconds, one unresolved JVM UUID reference in the prerequisite picker. This is a compiler failure, not behavioral RED.
2. Corrected main/test compile: exit0 after33seconds, both source compilations executed.
3. Added native-callback regression source compile: exit0 after14seconds; main unchanged/up-to-date, test compilation executed.
4. Full independent stream adaptation compile: exit0 after23seconds, test generator and main/test compilations executed.
5. Later final test compile failed on the typed StableId test constructor's missing entryId; main compilation succeeded. This is another compiler failure, not behavioral RED. Corrected only that test argument.
6. Final source compile: exit0 after15seconds. After the final two actual-native first-read test additions, final closure compile also exits0 after15seconds. Main remains byte-unchanged from its earlier successful executed compile; final test compilation executes, not merely UP-TO-DATE.

Exact terminal commands/logs/results/supervisor bounds are retained under the named `web-*.{command,log,result,supervisor}` evidence. Final prefix is `web-closure-source-compile`. All invocations are terminal, with no browser/device process launched. `git diff --check` is clean. No commit identity is fabricated as having been tested before it exists.

Eight pure binding/classification test methods were prepared, seven before the first implementation and one later. Nine native IndexedDB/production-callback regression sources and the full presentation-data method were prepared subsequently. **No behavioral RED/GREEN or JS test PASS is claimed for this stage.** Compilation is not test execution; historical R5/T17/native Desktop results do not substitute for the new Web behavior.

One supervisor selection mistake temporarily added four uniquely named Web command/log files to the R5 evidence directory. After that owning invocation terminated, only those new files were relocated to Web evidence, then all148 original R5 files plus the manifest were reverified unchanged. Subsequent builds use the Web-local supervisor. The preserved R5 Library package is unaffected.

## Prepared test evidence levels, all execution pending

- `WebAcquisitionBindingTest`:8 methods for unknown/zero/exact-long money, signed manual input, excluded target, historical/current receipt values, typed missing/number/flag/identity values and initial classification versus protected refresh navigation availability. These are pure display/classification tests, not rendered navigation evidence.
- `AcquisitionUiTest`:9 prepared native-IDB/production-callback methods. Synthetic20 card→preview→cancel/reentry/review replacement without a financial ID; callback purchase/saved-evidence/reopen/Undo; exact canonical manual fields; protected default read-only refusal; pending/uninitialized first failure; stale draft/disposal refusal; Shared new-only funding without old refill; actual first-read blocked by a task-owned native transaction; actual corrupt first native load with no legacy fallback. Bodies have an8-second cancellation bound within the ordinary10-second Mocha bound. Despite its original planned filename, this is not Compose pixel/DOM input automation.
- `WebAcquisitionPresentationMatrixTest`:1 prepared full83,818 binding-data method. A declared test-only Gradle task adapts the accepted unchanged input fixture/Shared source presentation stream at its JSON/resource boundary, preserving original assertions/denominators/classifications and adding observations. The test JSON helper is jsTest-only. Expected rows/nulls and approved overlay are served from unchanged original locations, not main/release assets. No83,818 paid receipts or rendered frames are invented.

The full stream retains the separate confirmed/source-unverified/admission-blocked/compound-fixture-gap/reused-financial classifications. Its counters and source assertions are prepared, not executed counts. The30-minute full-matrix Mocha bound is explicit opt-in; a matching external total/progress/no-progress supervisor and measured representative pilot remain prerequisites before any later full run. No sample timing, projection, coverage or actual runtime counter claim is made now.

## Blocker and remaining acceptance

Exact stopped action: normal own-cloud Firefox `:webApp:jsBrowserTest` and all dependent native-IDB/callback/full-matrix/renderer execution. Reason: the prior unidentified browser destination denial remains unresolved; existing logs did not establish its exact domain. The normal test route is not retried, no domain is guessed, and no endpoint probe, alternate route or settings change is used. This stage itself performs no browser launch or denied-action retry.

Actual WebGL/default renderer viability is **NOT VERIFIED**, not asserted universally unavailable. Prepared callback/binding test code is not a supported rendered Compose browser-input suite. Actual pixels/input/resize/system back/offline transitions, write/reopen in a fresh browser process, native-IDB behavior with the newly used saved decoder, performance pilot/full83,818 execution and offline Main bootstrap remain **BLOCKED / NOT VERIFIED**. Android device/instrumentation/server acceptance and original historical Desktop full-wrapper NOT PASS qualifications remain separate and unchanged.

This is eligible only for bounded fresh source/compile review and qualified preservation. It is not fullT18 PASS, visual approval, restoration of lost Web/T19/T20 bytes, release readiness or rollout authority. Production gates remain false. No main/force/merge/deploy/live-account change is performed.
