# Web source amendment1: W1/W2 only

The negative Web source review SHA25674b4e41f664204dda556dd60a4e93134f83fd98303624ea394ac334f5ec11444 remains bound to its unchanged original18-path freeze, report, patch and52-artifact manifest. This separate four-file amendment addresses only its two source findings; it is not restoration of lost source or full Web runtime acceptance.

## Source correction

W1: WebCanonicalReadState.loaded now retains an acknowledged protected classification within the current owner/root even if a later successful refresh has no Loaded head. Fresh successful empty discovery may still acknowledge legacy mode. A new prepared regression explicitly contrasts fresh loaded(false) with protected begin().loaded(false), checks mounted-navigation availability and repeated empty refresh protection. The existing owner lifecycle creates a separate state for a new root; no cross-owner persistence policy is added.

W2: Unowned Magic catalog cards and detail content now consume the existing paired Shared quote through AcquisitionEntrySummary. Canonical cards/details no longer use legacy spellUsability to represent acquisition admission and no longer expose an independent openTarget/add button that bypasses the paired request. Legacy casting/admission/add content is confined to legacy mode. The summary continues to expose Known/Unknown price and blocked/choice status, and now presents the existing Shared acknowledged-base and planned requirement trees read-only. No external-confirmation or selection mutation is available from a card quote. A trailing onOpen callback closes the spell detail only when its exact paired request is opened. No layout redesign, UI calculator, rule, schema or production gate is introduced.

The new prepared spell binding regression checks Shared unknown/blocked summary and typed actual/required values. It is a binding-source regression, not rendered Magic input proof. Magic source integration and paired request gating are separately available for source review in the amendment patch.

## Actual bounded verification

Normal approved task-local Gradle command: :webApp:compileKotlinJs :webApp:compileTestKotlinJs, with the same900-second supervisor bound, no daemon/parallel/build cache. Terminal exit0 after27supervisor seconds; Gradle reports BUILD SUCCESSFUL in26s. Both Web main and Web test compilation tasks execute, not merely UP-TO-DATE. Shared JS and test oracle generation remain unchanged/up-to-date. Existing Gradle deprecation and Android metrics initialization warnings remain in the complete log; no settings are changed to hide them. git diff --check passes.

The two new test methods were written and copied before the production correction, but no test was executed against either old or corrected code. All20prepared methods remain NOT EXECUTED:10binding/classification,9native-IDB/production-callback,1full83,818presentation-data method. This is not behavioral RED/GREEN or TDD proof. Compilation is not a JS test PASS.

Exact amended source identities and before hashes are in source-freeze.json; amendment.patch is relative to the negative reviewed source copies, not a broad old-file replacement. current-source-inventory.json binds all18current source paths, unchanged2generated compiler inputs, the executed compile result and unchanged historical artifacts. The complete command/log/result/supervisor files are copied into this amendment directory. No other product/test paths changed in this round. All52original Web technical artifacts and all148original R5 technical artifacts plus its manifest were reverified unchanged.

## Continuing blocker

Normal own-cloud Firefox :webApp:jsBrowserTest remains STOPPED/BLOCKED because the prior unidentified browser destination denial is unresolved. No launch, retry, endpoint probe, alternate route or browser/security/settings change occurred. Actual native callback behavior, WebGL/default renderer viability, full83,818execution/pilot/throughput and real Compose input/pixel/system journeys remain BLOCKED/NOT VERIFIED. Historical neighboring-platform results cannot discharge these current Web gates. Source/compile-only amendment review and qualified preservation are the only requested acceptance.
