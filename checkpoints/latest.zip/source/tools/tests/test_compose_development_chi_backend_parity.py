from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
SHARED = ROOT / 'shared/src/commonMain/kotlin'
HARNESS = ROOT / 'tools/tests/kotlin/DevelopmentChiParityHarness.kt'
ANDROID_CONTROLLER = ROOT / 'app/src/main/java/com/furybook/android/state/CharacterController.kt'
DESKTOP_STATE = ROOT / 'desktopApp/src/main/kotlin/com/furybook/desktop/DesktopAppState.kt'


def test_android_and_desktop_route_development_and_chi_through_shared_application():
    android = ANDROID_CONTROLLER.read_text(encoding='utf-8')
    desktop = DESKTOP_STATE.read_text(encoding='utf-8')
    mapping = {
        'setDevelopmentRank': 'application.development.setRank',
        'setChiEnabled': 'application.development.setChiEnabled',
        'setChiBonusRanks': 'application.development.setChiBonusRanks',
        'restoreChi': 'application.development.restoreChi',
        'changeChi': 'application.development.changeChi',
    }
    for method, call in mapping.items():
        assert f'fun {method}' in android and call in android, method
        assert f'fun {method}' in desktop and call in desktop, method
    assert 'CharacterSession' not in android + desktop
    assert 'fun mutate(' not in desktop


def test_shared_development_martial_and_chi_behavior_harness():
    kotlinc = shutil.which('kotlinc')
    assert kotlinc is not None
    sources = sorted((SHARED / 'com/furybook/dubl/model').glob('*.kt'))
    sources += [
        SHARED / 'com/furybook/dubl/data/CharacterStore.kt',
        SHARED / 'com/furybook/dubl/state/CharacterSession.kt',
        HARNESS,
    ]
    with tempfile.TemporaryDirectory() as td:
        jar = Path(td) / 'development-chi.jar'
        compiled = subprocess.run(
            [kotlinc, *map(str, sources), '-include-runtime', '-d', str(jar)],
            cwd=ROOT,
            capture_output=True,
            text=True,
        )
        assert compiled.returncode == 0, compiled.stderr
        result = subprocess.run(['java', '-jar', str(jar)], cwd=ROOT, capture_output=True, text=True)
        assert result.returncode == 0, result.stderr
        assert 'DEVELOPMENT_CHI_PARITY_OK' in result.stdout
