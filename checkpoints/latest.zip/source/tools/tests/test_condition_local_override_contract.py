from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
SHARED = ROOT / "shared/src/commonMain/kotlin"
HARNESS = ROOT / "tools/tests/kotlin/ConditionLocalOverrideHarness.kt"


def test_conditions_support_local_override_custom_add_reset_and_delete():
    kotlinc = shutil.which("kotlinc")
    assert kotlinc is not None
    sources = sorted((SHARED / "com/furybook/dubl/model").glob("*.kt"))
    sources += [
        SHARED / "com/furybook/dubl/data/CharacterExtrasStore.kt",
        SHARED / "com/furybook/dubl/state/CharacterExtrasSession.kt",
        HARNESS,
    ]
    with tempfile.TemporaryDirectory() as td:
        jar = Path(td) / "condition-local-override.jar"
        compiled = subprocess.run([kotlinc, *map(str, sources), "-include-runtime", "-d", str(jar)], cwd=ROOT, capture_output=True, text=True)
        assert compiled.returncode == 0, compiled.stderr
        result = subprocess.run(["java", "-jar", str(jar)], cwd=ROOT, capture_output=True, text=True)
        assert result.returncode == 0, result.stderr + result.stdout
        assert "CONDITION_LOCAL_OVERRIDE_OK" in result.stdout
