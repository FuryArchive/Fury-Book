"""Fury Content Pack tooling."""
