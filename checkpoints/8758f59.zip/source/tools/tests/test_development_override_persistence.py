from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
SHARED = ROOT / "shared/src/commonMain/kotlin"
HARNESS = ROOT / "tools/tests/kotlin/DevelopmentOverridePersistenceHarness.kt"


def test_development_overrides_and_custom_entries_round_trip_through_snapshot_codec():
    kotlinc = shutil.which("kotlinc")
    assert kotlinc is not None
    sources = sorted((SHARED / "com/furybook/dubl/model").glob("*.kt"))
    sources += [
        SHARED / "com/furybook/core/json/MiniJson.kt",
        SHARED / "com/furybook/dubl/data/SnapshotCodec.kt",
        HARNESS,
    ]
    with tempfile.TemporaryDirectory() as td:
        jar = Path(td) / "development-override-persistence.jar"
        compiled = subprocess.run(
            [kotlinc, *map(str, sources), "-include-runtime", "-d", str(jar)],
            cwd=ROOT,
            capture_output=True,
            text=True,
        )
        assert compiled.returncode == 0, compiled.stderr
        result = subprocess.run(["java", "-jar", str(jar)], cwd=ROOT, capture_output=True, text=True)
        assert result.returncode == 0, result.stderr + result.stdout
        assert "DEVELOPMENT_OVERRIDE_PERSISTENCE_OK" in result.stdout
